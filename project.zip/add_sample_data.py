def generate_grocery_products():
    """식료품 150개의 샘플 데이터를 생성합니다."""
    # 이 함수는 현재 사용하지 않습니다.
    return []

if __name__ == "__main__":
    print("이 스크립트는 더 이상 독립적으로 실행되지 않습니다.")
    print("app.py에서 직접 샘플 데이터를 생성합니다.") 